#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <SPI.h>
#include <MFRC522.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <WiFiClientSecure.h>

#define SS_PIN     5
#define RST_PIN    2
#define BUZZER_PIN 4

MFRC522 rfid(SS_PIN, RST_PIN);
LiquidCrystal_I2C lcd(0x27, 16, 2);

// Ganti dengan WiFi kamu
const char* ssid = "Kost aisyah";
const char* password = "aisyah19";

// Ganti dengan URL ngrok kamu (API Laravel)
const String serverName = "https://72b9-139-195-168-68.ngrok-free.app/api/presensi";


String kirimData(String uid) {
  if (WiFi.status() == WL_CONNECTED) {
    WiFiClientSecure client;
    client.setInsecure(); // ⛔ abaikan verifikasi SSL (boleh untuk testing/ngrok)

    HTTPClient http;
    http.begin(client, serverName); // gunakan client TLS di sini
    http.addHeader("Content-Type", "application/json");

    String jsonData = "{\"uid\":\"" + uid + "\"}";
    int httpResponseCode = http.POST(jsonData);
    String response = "";

    if (httpResponseCode > 0) {
      response = http.getString();
      Serial.println("RESPON SERVER: " + response);
    } else {
      Serial.print("HTTP Error: ");
      Serial.println(httpResponseCode);
      response = "Gagal";
    }

    http.end();
    return response;
  } else {
    return "Tidak Terhubung";
  }
}


void setup() {
  Serial.begin(115200);
  SPI.begin();            // Inisialisasi SPI
  rfid.PCD_Init();        // Inisialisasi RFID
  pinMode(BUZZER_PIN, OUTPUT);

  Wire.begin(21, 22);     // SDA, SCL untuk I2C LCD
  lcd.init();
  lcd.backlight();
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Presensi RFID");

  // Koneksi WiFi
  WiFi.begin(ssid, password);
  lcd.setCursor(0, 1);
  lcd.print("Sambung WiFi...");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  lcd.clear();
  lcd.print("WiFi Terhubung");
  delay(1000);
  lcd.clear();
  lcd.print("Tempelkan Kartu");
}

void loop() {
  if (!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial()) return;

  // Ambil UID kartu
  String uid = "";
  for (byte i = 0; i < rfid.uid.size; i++) {
    if (rfid.uid.uidByte[i] < 0x10) uid += "0";
    uid += String(rfid.uid.uidByte[i], HEX);
  }
  uid.toUpperCase();
  Serial.println("UID: " + uid);

  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Kartu Terdeteksi");

  // Bunyikan buzzer
  digitalWrite(BUZZER_PIN, HIGH);
  delay(300);
  digitalWrite(BUZZER_PIN, LOW);

  // Kirim ke server dan tampilkan respons
  String hasil = kirimData(uid);

  // Tampilkan hasil di LCD
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Presensi OK");
  lcd.setCursor(0, 1);

  if (hasil.indexOf("Masuk") != -1) {
    lcd.print("Status: Masuk");
  } else if (hasil.indexOf("Keluar") != -1) {
    lcd.print("Status: Keluar");
  } else {
    lcd.print("Status: Error");
  }

  delay(3000);
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Tempelkan Kartu");

  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();
}
